package com.dicoding.githubapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailUser : AppCompatActivity() {

    companion object{
        const val EXTRA_DATA = "extra_data"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_user)

        val imgUser: ImageView = findViewById(R.id.img_detail_user)
        val tvUsername: TextView = findViewById(R.id.tv_username)
        val tvName: TextView = findViewById(R.id.tv_detail_name)
        val tvFollower: TextView = findViewById(R.id.tv_follower)
        val tvFollowing: TextView = findViewById(R.id.tv_following)
        val tvCompany: TextView = findViewById(R.id.tv_company)
        val tvLocation: TextView = findViewById(R.id.tv_location)
        val tvRepository: TextView = findViewById(R.id.tv_repository)

        val data = intent.getParcelableExtra<User>(EXTRA_DATA)

        imgUser.setImageResource(data?.img?:0)
        tvUsername.text = data?.username
        tvName.text = data?.name
        tvFollower.text = data?.follower
        tvFollowing.text = data?.following
        tvCompany.text = data?.company
        tvLocation.text = data?.location
        tvRepository.text = data?.repository

        val actionbar = supportActionBar

        actionbar!!.title = "About"

        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}