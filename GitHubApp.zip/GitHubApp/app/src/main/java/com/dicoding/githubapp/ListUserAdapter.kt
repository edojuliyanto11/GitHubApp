package com.dicoding.githubapp

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ListUserAdapter(private val listUser:ArrayList<User>):RecyclerView.Adapter<ListUserAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgUser: ImageView = itemView.findViewById(R.id.img_user)
        var tvName: TextView = itemView.findViewById(R.id.tv_name)
        var btnFav: Button = itemView.findViewById(R.id.btn_Fav)
        var btnSha: Button = itemView.findViewById(R.id.btn_Sha)
        var btnFol: Button = itemView.findViewById(R.id.btn_Fol)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (img, _, name, _, _, _, _, _) = listUser[position]
        holder.imgUser.setImageResource(img)
        holder.tvName.text = name

        holder.btnFav.setOnClickListener {
            Toast.makeText(
                holder.itemView.context,
                "Favorite " + listUser[position].name,
                Toast.LENGTH_SHORT
            ).show()
        }

        holder.btnSha.setOnClickListener {
            Toast.makeText(
                it.context,
                "Share " + listUser[position].name,
                Toast.LENGTH_SHORT
            ).show()
        }

        holder.btnFol.setOnClickListener {
            Toast.makeText(
                it.context,
                "Follow " + listUser[position].name,
                Toast.LENGTH_SHORT
            ).show()
        }

        holder.itemView.setOnClickListener{
            Toast.makeText(it.context, "Kamu memilih " + listUser[position].name, Toast.LENGTH_SHORT).show()
            Log.d("log_click", "tombol terklik")
        }


        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listUser[holder.adapterPosition]) }
    }

    override fun getItemCount(): Int = listUser.size

    interface OnItemClickCallback {
        fun onItemClicked(data: User)
    }
}