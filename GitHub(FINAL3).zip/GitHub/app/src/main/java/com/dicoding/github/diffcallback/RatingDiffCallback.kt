package com.dicoding.github.diffcallback

import androidx.recyclerview.widget.DiffUtil
import com.dicoding.github.user.User

class RatingDiffCallback(
    private val mOldNoteList: List<User>,
    private val mNewNoteList: List<User>
) : DiffUtil.Callback() {
    override fun getOldListSize(): Int {
        return mOldNoteList.size
    }

    override fun getNewListSize(): Int {
        return mNewNoteList.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return mOldNoteList[oldItemPosition].id == mNewNoteList[newItemPosition].id
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return when {
            mOldNoteList[oldItemPosition].login != mNewNoteList[newItemPosition].login -> {
                false
            }
            mOldNoteList[oldItemPosition].id != mNewNoteList[newItemPosition].id -> {
                false
            }
            mOldNoteList[oldItemPosition].avatar_url != mNewNoteList[newItemPosition].avatar_url -> {
                false
            }
            else -> true
        }
    }
}