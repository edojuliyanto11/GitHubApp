package com.dicoding.github.user


data class UserResponse(
    val items: ArrayList<User>
)
