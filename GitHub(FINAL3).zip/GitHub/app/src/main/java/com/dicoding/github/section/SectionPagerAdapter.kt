package com.dicoding.github.section

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.dicoding.github.followers.FollowersFragment
import com.dicoding.github.following.FollowingFragment

class SectionPagerAdapter(activity: AppCompatActivity, private val bundle: Bundle) :
    FragmentStateAdapter(activity) {

    override fun getItemCount(): Int {
        return 2
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> FollowersFragment().apply { arguments = bundle }
            1 -> FollowingFragment().apply { arguments = bundle }
            else -> throw IllegalStateException("position not available")
        }
    }
}
