package com.dicoding.github.api

import com.dicoding.github.BuildConfig
import com.dicoding.github.detail.DetailUserResponse
import com.dicoding.github.user.User
import com.dicoding.github.user.UserResponse
import retrofit2.Call
import retrofit2.http.*

interface Api {
    @GET("search/users")
    @Headers("Authorization: ${BuildConfig.KEY}")
    fun search(
        @Query("q") query: String
    ): Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: ${BuildConfig.KEY}")
    fun detail(
        @Path("username") username: String
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: ${BuildConfig.KEY}")
    fun followers(
        @Path("username") username: String
    ): Call<ArrayList<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: ${BuildConfig.KEY}")
    fun following(
        @Path("username") username: String
    ): Call<ArrayList<User>>
}